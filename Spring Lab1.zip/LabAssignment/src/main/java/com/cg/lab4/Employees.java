package com.cg.lab4;

import java.util.List;


public class Employees 
{
	List<Employee> emplist;

	public List<Employee> getEmplist() {
		return emplist;
	}

	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	
	
}
